import json
import os
import time
import uuid
from decimal import Decimal

import boto3
from botocore.exceptions import ClientError

dynamodb = boto3.resource("dynamodb")
products = dynamodb.Table(os.environ.get("PRODUCTS_TABLE", "products"))
sales = dynamodb.Table(os.environ.get("SALES_TABLE", "sales"))
LOW_STOCK_LIMIT = 5


def _default(o):
    if isinstance(o, Decimal):
        return int(o) if o % 1 == 0 else float(o)
    raise TypeError(f"Cannot serialize {type(o)}")


def resp(code, body):
    return {
        "statusCode": code,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body, default=_default),
    }


def list_products():
    return products.scan().get("Items", [])


def create_product(data):
    if not data.get("name") or "price" not in data:
        return resp(400, {"error": "name and price are required"})
    item = {
        "id": str(uuid.uuid4()),
        "name": data["name"],
        "price": Decimal(str(data["price"])),
        "stock": int(data.get("stock", 0)),
    }
    products.put_item(Item=item)
    return resp(201, item)


def update_product(pid, data):
    allowed = {k: data[k] for k in ("name", "price", "stock") if k in data}
    if not allowed:
        return resp(400, {"error": "nothing to update"})
    if "price" in allowed:
        allowed["price"] = Decimal(str(allowed["price"]))
    if "stock" in allowed:
        allowed["stock"] = int(allowed["stock"])
    names = {f"#{k}": k for k in allowed}
    values = {f":{k}": v for k, v in allowed.items()}
    expr = "SET " + ", ".join(f"#{k} = :{k}" for k in allowed)
    try:
        r = products.update_item(
            Key={"id": pid},
            UpdateExpression=expr,
            ExpressionAttributeNames=names,
            ExpressionAttributeValues=values,
            ConditionExpression="attribute_exists(id)",
            ReturnValues="ALL_NEW",
        )
    except ClientError as e:
        if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
            return resp(404, {"error": "product not found"})
        raise
    return resp(200, r["Attributes"])


def create_sale(data):
    items = data.get("items") or []
    if not items:
        return resp(400, {"error": "items are required"})
    done, lines, total = [], [], Decimal(0)
    try:
        for it in items:
            qty = int(it["qty"])
            r = products.update_item(
                Key={"id": it["product_id"]},
                UpdateExpression="SET stock = stock - :q",
                ConditionExpression="attribute_exists(id) AND stock >= :q",
                ExpressionAttributeValues={":q": qty},
                ReturnValues="ALL_NEW",
            )
            done.append((it["product_id"], qty))
            p = r["Attributes"]
            line_total = p["price"] * qty
            total += line_total
            lines.append({"product_id": p["id"], "name": p["name"], "qty": qty,
                          "price": p["price"], "line_total": line_total})
    except ClientError as e:
        for pid, qty in done:  # roll back stock already deducted
            products.update_item(
                Key={"id": pid},
                UpdateExpression="SET stock = stock + :q",
                ExpressionAttributeValues={":q": qty},
            )
        if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
            return resp(409, {"error": "product missing or insufficient stock"})
        raise
    sale = {"id": str(uuid.uuid4()), "created_at": int(time.time()),
            "items": lines, "total": total}
    sales.put_item(Item=sale)
    return resp(201, sale)


def handler(event, context):
    headers = {k.lower(): v for k, v in (event.get("headers") or {}).items()}
    if headers.get("x-api-key") != os.environ.get("API_KEY"):
        return resp(401, {"error": "unauthorized"})

    method = event["requestContext"]["http"]["method"]
    path = (event.get("rawPath") or "/").rstrip("/") or "/"
    try:
        data = json.loads(event["body"]) if event.get("body") else {}
    except json.JSONDecodeError:
        return resp(400, {"error": "invalid JSON"})
    parts = path.strip("/").split("/")

    if parts == ["products"]:
        if method == "GET":
            return resp(200, list_products())
        if method == "POST":
            return create_product(data)
    elif len(parts) == 2 and parts[0] == "products":
        if method == "PUT":
            return update_product(parts[1], data)
        if method == "DELETE":
            products.delete_item(Key={"id": parts[1]})
            return resp(200, {"deleted": parts[1]})
    elif parts == ["sales"]:
        if method == "GET":
            items = sorted(sales.scan().get("Items", []),
                           key=lambda s: s["created_at"], reverse=True)
            return resp(200, items)
        if method == "POST":
            return create_sale(data)
    elif parts == ["reports", "low-stock"] and method == "GET":
        return resp(200, [p for p in list_products() if p["stock"] <= LOW_STOCK_LIMIT])
    return resp(404, {"error": "not found"})
