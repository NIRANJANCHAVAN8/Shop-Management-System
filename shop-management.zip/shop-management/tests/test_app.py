import os
import sys

os.environ.setdefault("AWS_DEFAULT_REGION", "ap-south-1")
os.environ["API_KEY"] = "secret"
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

import app  # noqa: E402


def event(headers=None, method="GET", path="/products"):
    return {"headers": headers or {}, "rawPath": path,
            "requestContext": {"http": {"method": method}}}


def test_missing_key_is_rejected():
    assert app.handler(event(), None)["statusCode"] == 401


def test_unknown_route_returns_404():
    r = app.handler(event({"x-api-key": "secret"}, path="/nope"), None)
    assert r["statusCode"] == 404
