window.API_URL = "http://localhost:3000"; // overwritten automatically by the pipeline
